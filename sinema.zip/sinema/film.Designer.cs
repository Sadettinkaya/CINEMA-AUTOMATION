﻿namespace sinema
{
    partial class film
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.FilmListeleB = new System.Windows.Forms.Button();
            this.FilmAraB = new System.Windows.Forms.Button();
            this.textBoxFilmAdi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.FilmGuncelleB = new System.Windows.Forms.Button();
            this.LGFilmID = new System.Windows.Forms.Label();
            this.LGfilmadi = new System.Windows.Forms.Label();
            this.LGyönetmen = new System.Windows.Forms.Label();
            this.LGIMDb = new System.Windows.Forms.Label();
            this.GtextBoxID = new System.Windows.Forms.TextBox();
            this.GtextBoxAdi = new System.Windows.Forms.TextBox();
            this.GtextBoxYönetmen = new System.Windows.Forms.TextBox();
            this.GtextBoxIMDb = new System.Windows.Forms.TextBox();
            this.StextBoxIMDb = new System.Windows.Forms.TextBox();
            this.StextBoxYönetmen = new System.Windows.Forms.TextBox();
            this.StextBoxAdi = new System.Windows.Forms.TextBox();
            this.StextBoxID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.FilmSilB = new System.Windows.Forms.Button();
            this.EtextBoxIMDb = new System.Windows.Forms.TextBox();
            this.EtextBoxYönetmen = new System.Windows.Forms.TextBox();
            this.EtextBoxAdi = new System.Windows.Forms.TextBox();
            this.EtextBoxID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.FilmEkleB = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(757, 396);
            this.dataGridView1.TabIndex = 0;
            // 
            // FilmListeleB
            // 
            this.FilmListeleB.Location = new System.Drawing.Point(853, 341);
            this.FilmListeleB.Name = "FilmListeleB";
            this.FilmListeleB.Size = new System.Drawing.Size(327, 81);
            this.FilmListeleB.TabIndex = 1;
            this.FilmListeleB.Text = "Film Listele";
            this.FilmListeleB.UseVisualStyleBackColor = true;
            this.FilmListeleB.Click += new System.EventHandler(this.FilmListeleB_Click);
            // 
            // FilmAraB
            // 
            this.FilmAraB.Location = new System.Drawing.Point(1263, 341);
            this.FilmAraB.Name = "FilmAraB";
            this.FilmAraB.Size = new System.Drawing.Size(173, 53);
            this.FilmAraB.TabIndex = 2;
            this.FilmAraB.Text = "Film Ara";
            this.FilmAraB.UseVisualStyleBackColor = true;
            this.FilmAraB.Click += new System.EventHandler(this.FilmAraB_Click);
            // 
            // textBoxFilmAdi
            // 
            this.textBoxFilmAdi.Location = new System.Drawing.Point(1310, 400);
            this.textBoxFilmAdi.Name = "textBoxFilmAdi";
            this.textBoxFilmAdi.Size = new System.Drawing.Size(126, 22);
            this.textBoxFilmAdi.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1245, 406);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Film Adı:";
            // 
            // FilmGuncelleB
            // 
            this.FilmGuncelleB.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.FilmGuncelleB.Location = new System.Drawing.Point(804, 12);
            this.FilmGuncelleB.Name = "FilmGuncelleB";
            this.FilmGuncelleB.Size = new System.Drawing.Size(191, 53);
            this.FilmGuncelleB.TabIndex = 5;
            this.FilmGuncelleB.Text = "Film Guncelle";
            this.FilmGuncelleB.UseVisualStyleBackColor = false;
            this.FilmGuncelleB.Click += new System.EventHandler(this.FilmGuncelleB_Click);
            // 
            // LGFilmID
            // 
            this.LGFilmID.AutoSize = true;
            this.LGFilmID.Location = new System.Drawing.Point(804, 99);
            this.LGFilmID.Name = "LGFilmID";
            this.LGFilmID.Size = new System.Drawing.Size(48, 16);
            this.LGFilmID.TabIndex = 6;
            this.LGFilmID.Text = "Film ID";
            // 
            // LGfilmadi
            // 
            this.LGfilmadi.AutoSize = true;
            this.LGfilmadi.Location = new System.Drawing.Point(804, 153);
            this.LGfilmadi.Name = "LGfilmadi";
            this.LGfilmadi.Size = new System.Drawing.Size(55, 16);
            this.LGfilmadi.TabIndex = 7;
            this.LGfilmadi.Text = "Film Adi";
            // 
            // LGyönetmen
            // 
            this.LGyönetmen.AutoSize = true;
            this.LGyönetmen.Location = new System.Drawing.Point(795, 211);
            this.LGyönetmen.Name = "LGyönetmen";
            this.LGyönetmen.Size = new System.Drawing.Size(68, 16);
            this.LGyönetmen.TabIndex = 8;
            this.LGyönetmen.Text = "Yönetmen";
            // 
            // LGIMDb
            // 
            this.LGIMDb.AutoSize = true;
            this.LGIMDb.Location = new System.Drawing.Point(804, 274);
            this.LGIMDb.Name = "LGIMDb";
            this.LGIMDb.Size = new System.Drawing.Size(39, 16);
            this.LGIMDb.TabIndex = 9;
            this.LGIMDb.Text = "IMDb";
            // 
            // GtextBoxID
            // 
            this.GtextBoxID.Location = new System.Drawing.Point(869, 96);
            this.GtextBoxID.Name = "GtextBoxID";
            this.GtextBoxID.Size = new System.Drawing.Size(126, 22);
            this.GtextBoxID.TabIndex = 10;
            // 
            // GtextBoxAdi
            // 
            this.GtextBoxAdi.Location = new System.Drawing.Point(869, 147);
            this.GtextBoxAdi.Name = "GtextBoxAdi";
            this.GtextBoxAdi.Size = new System.Drawing.Size(126, 22);
            this.GtextBoxAdi.TabIndex = 11;
            // 
            // GtextBoxYönetmen
            // 
            this.GtextBoxYönetmen.Location = new System.Drawing.Point(869, 205);
            this.GtextBoxYönetmen.Name = "GtextBoxYönetmen";
            this.GtextBoxYönetmen.Size = new System.Drawing.Size(126, 22);
            this.GtextBoxYönetmen.TabIndex = 12;
            // 
            // GtextBoxIMDb
            // 
            this.GtextBoxIMDb.Location = new System.Drawing.Point(869, 268);
            this.GtextBoxIMDb.Name = "GtextBoxIMDb";
            this.GtextBoxIMDb.Size = new System.Drawing.Size(126, 22);
            this.GtextBoxIMDb.TabIndex = 13;
            // 
            // StextBoxIMDb
            // 
            this.StextBoxIMDb.Location = new System.Drawing.Point(1090, 268);
            this.StextBoxIMDb.Name = "StextBoxIMDb";
            this.StextBoxIMDb.Size = new System.Drawing.Size(126, 22);
            this.StextBoxIMDb.TabIndex = 22;
            // 
            // StextBoxYönetmen
            // 
            this.StextBoxYönetmen.Location = new System.Drawing.Point(1090, 205);
            this.StextBoxYönetmen.Name = "StextBoxYönetmen";
            this.StextBoxYönetmen.Size = new System.Drawing.Size(126, 22);
            this.StextBoxYönetmen.TabIndex = 21;
            // 
            // StextBoxAdi
            // 
            this.StextBoxAdi.Location = new System.Drawing.Point(1090, 147);
            this.StextBoxAdi.Name = "StextBoxAdi";
            this.StextBoxAdi.Size = new System.Drawing.Size(126, 22);
            this.StextBoxAdi.TabIndex = 20;
            // 
            // StextBoxID
            // 
            this.StextBoxID.Location = new System.Drawing.Point(1090, 96);
            this.StextBoxID.Name = "StextBoxID";
            this.StextBoxID.Size = new System.Drawing.Size(126, 22);
            this.StextBoxID.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1025, 274);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "IMDb";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1016, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Yönetmen";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1025, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "Film Adi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1025, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 16);
            this.label5.TabIndex = 15;
            this.label5.Text = "Film ID";
            // 
            // FilmSilB
            // 
            this.FilmSilB.Location = new System.Drawing.Point(1028, 12);
            this.FilmSilB.Name = "FilmSilB";
            this.FilmSilB.Size = new System.Drawing.Size(188, 53);
            this.FilmSilB.TabIndex = 14;
            this.FilmSilB.Text = "Film Sil";
            this.FilmSilB.UseVisualStyleBackColor = true;
            this.FilmSilB.Click += new System.EventHandler(this.FilmSilB_Click);
            // 
            // EtextBoxIMDb
            // 
            this.EtextBoxIMDb.Location = new System.Drawing.Point(1310, 268);
            this.EtextBoxIMDb.Name = "EtextBoxIMDb";
            this.EtextBoxIMDb.Size = new System.Drawing.Size(126, 22);
            this.EtextBoxIMDb.TabIndex = 31;
            // 
            // EtextBoxYönetmen
            // 
            this.EtextBoxYönetmen.Location = new System.Drawing.Point(1310, 205);
            this.EtextBoxYönetmen.Name = "EtextBoxYönetmen";
            this.EtextBoxYönetmen.Size = new System.Drawing.Size(126, 22);
            this.EtextBoxYönetmen.TabIndex = 30;
            // 
            // EtextBoxAdi
            // 
            this.EtextBoxAdi.Location = new System.Drawing.Point(1310, 147);
            this.EtextBoxAdi.Name = "EtextBoxAdi";
            this.EtextBoxAdi.Size = new System.Drawing.Size(126, 22);
            this.EtextBoxAdi.TabIndex = 29;
            // 
            // EtextBoxID
            // 
            this.EtextBoxID.Location = new System.Drawing.Point(1310, 96);
            this.EtextBoxID.Name = "EtextBoxID";
            this.EtextBoxID.Size = new System.Drawing.Size(126, 22);
            this.EtextBoxID.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1245, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 16);
            this.label6.TabIndex = 27;
            this.label6.Text = "IMDb";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1236, 211);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 16);
            this.label7.TabIndex = 26;
            this.label7.Text = "Yönetmen";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1245, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 16);
            this.label8.TabIndex = 25;
            this.label8.Text = "Film Adi";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1245, 99);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 16);
            this.label9.TabIndex = 24;
            this.label9.Text = "Film ID";
            // 
            // FilmEkleB
            // 
            this.FilmEkleB.Location = new System.Drawing.Point(1248, 12);
            this.FilmEkleB.Name = "FilmEkleB";
            this.FilmEkleB.Size = new System.Drawing.Size(188, 53);
            this.FilmEkleB.TabIndex = 23;
            this.FilmEkleB.Text = "Film Ekle";
            this.FilmEkleB.UseVisualStyleBackColor = true;
            this.FilmEkleB.Click += new System.EventHandler(this.FilmEkleB_Click);
            // 
            // film
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1513, 451);
            this.Controls.Add(this.EtextBoxIMDb);
            this.Controls.Add(this.EtextBoxYönetmen);
            this.Controls.Add(this.EtextBoxAdi);
            this.Controls.Add(this.EtextBoxID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.FilmEkleB);
            this.Controls.Add(this.StextBoxIMDb);
            this.Controls.Add(this.StextBoxYönetmen);
            this.Controls.Add(this.StextBoxAdi);
            this.Controls.Add(this.StextBoxID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.FilmSilB);
            this.Controls.Add(this.GtextBoxIMDb);
            this.Controls.Add(this.GtextBoxYönetmen);
            this.Controls.Add(this.GtextBoxAdi);
            this.Controls.Add(this.GtextBoxID);
            this.Controls.Add(this.LGIMDb);
            this.Controls.Add(this.LGyönetmen);
            this.Controls.Add(this.LGfilmadi);
            this.Controls.Add(this.LGFilmID);
            this.Controls.Add(this.FilmGuncelleB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxFilmAdi);
            this.Controls.Add(this.FilmAraB);
            this.Controls.Add(this.FilmListeleB);
            this.Controls.Add(this.dataGridView1);
            this.Name = "film";
            this.Text = "film";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button FilmListeleB;
        private System.Windows.Forms.Button FilmAraB;
        private System.Windows.Forms.TextBox textBoxFilmAdi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button FilmGuncelleB;
        private System.Windows.Forms.Label LGFilmID;
        private System.Windows.Forms.Label LGfilmadi;
        private System.Windows.Forms.Label LGyönetmen;
        private System.Windows.Forms.Label LGIMDb;
        private System.Windows.Forms.TextBox GtextBoxID;
        private System.Windows.Forms.TextBox GtextBoxAdi;
        private System.Windows.Forms.TextBox GtextBoxYönetmen;
        private System.Windows.Forms.TextBox GtextBoxIMDb;
        private System.Windows.Forms.TextBox StextBoxIMDb;
        private System.Windows.Forms.TextBox StextBoxYönetmen;
        private System.Windows.Forms.TextBox StextBoxAdi;
        private System.Windows.Forms.TextBox StextBoxID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button FilmSilB;
        private System.Windows.Forms.TextBox EtextBoxIMDb;
        private System.Windows.Forms.TextBox EtextBoxYönetmen;
        private System.Windows.Forms.TextBox EtextBoxAdi;
        private System.Windows.Forms.TextBox EtextBoxID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button FilmEkleB;
    }
}